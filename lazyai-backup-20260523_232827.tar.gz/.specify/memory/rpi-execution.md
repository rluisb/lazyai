## Workflow: Bugfix 024 — start_chain MCP context bind mismatch [2026-05-11]

Type: Bugfix (Shortened RPI). Triggered by user report after live MCP invocation failed.

### REPRODUCE Phase
- Started: 2026-05-11
- Evidence: User invoked `orchestrator_start_chain` with arguments
  `[chain=bugfix, context=null, domainSkill=, modeSkill=, task=Bugfix issue #182 in worktree ...]`.
  Server returned: `Invalid start_chain input: json: cannot unmarshal string into Go struct
  field StartChainInput.context of type struct { CliTool types.HostCli ...; RootContext
  types.RootContextLayer ... }`.
- Conclusion: bug reproduces deterministically whenever `context` is delivered as a JSON
  string value (including the empty-string default emitted by MCP clients that fill in
  declared `WithString` fields). Omitting the arg or passing it as a JSON object works.
- Verdict: REPRODUCED.

### ROOT-CAUSE Phase
- Started: 2026-05-11
- Skill: read-only investigation (`grep`, `Read`).
- Findings:
  - Tool schema declares `mcp.WithString("context", mcp.Description("Optional execution
    context JSON"))` at `packages/orchestrator/internal/mcp/orchestrator.go:76`.
  - Input struct expects an object — `types.StartChainInput.Context *struct{ CliTool
    HostCli; RootContext RootContextLayer }` at
    `packages/orchestrator/internal/types/definitions.go:626-629`.
  - Handler binds via `req.BindArguments(&input)` (chain_lifecycle.go:61) which
    JSON-unmarshals args directly; a string value cannot decode into the struct.
- Downstream reach: `input.Context` is read in `compileChainPlan`
  (chain_lifecycle.go:235) and `cliContext` (chain_lifecycle.go:440). These read sites
  must continue to receive the same struct shape after the fix.
- Same-pattern audit (callable but no observed failure yet, out of scope):
  - `advance_chain.output` (string → `map[string]any`)
  - `advance_chain.usage` (string → `*StepUsage`)
  - `build_team.budget` (string → `*BudgetPolicy`)
  - `complete_task.result | usage | error`
  - `start_workflow.budget | context`
  - `advance_workflow.recovery`
  These will be flagged as a follow-up but not touched in this bugfix per scope rules.
- Verdict: ROOT CAUSE IDENTIFIED — schema/decoder contract mismatch on `start_chain.context`.

### PLAN-FIX Phase
- Started: 2026-05-11
- Skill: manual planning (Shortened RPI, bugfix track).
- Artifact: `specs/bugfixes/024-mcp-start-chain-context-bind/plan.md`
- Verdict: GO.

### Human Gate (Plan approval)
- Status: AUTO-PROCEED (user issued "work without stopping for clarifying questions"
  directive after plan was written; plan logged for after-the-fact review).

### IMPLEMENT Phase (RED → GREEN)
- Started: 2026-05-11
- RED: Added table-driven `TestStartChainAcceptsContextShapes` to
  `packages/orchestrator/internal/mcp/orchestrator_test.go`. Before the fix, 2 of 6
  sub-cases failed with the reported error (`empty_string`, `stringified_json`).
- GREEN: Replaced `StartChain` handler body in
  `packages/orchestrator/internal/mcp/orchestrator.go` so it binds to a local raw
  struct using `json.RawMessage` for `context`, then routes through new helper
  `decodeStartChainContext` in `chain_lifecycle.go`. The helper tolerates
  omitted / null / empty-string / object / stringified-JSON shapes and rejects
  unparseable strings via the existing `Invalid start_chain context: …` envelope.
- Diff scope: 2 production files (orchestrator.go + chain_lifecycle.go), 1 test file.
  ~50 LOC production, ~95 LOC test.
- Verdict: PASS.

### VERIFY Phase
- `go test ./packages/orchestrator/...` — all packages PASS, including
  `internal/mcp` 3.343s (existing chain/team/workflow/dispatch suites unchanged).
- `go vet ./packages/orchestrator/...` — clean (no findings).
- `go build ./packages/orchestrator/... ./packages/cli/... ./packages/diffviewer/...`
  — clean across workspace modules.
- Pre-existing diagnostics noted but untouched: `auth_test.go` testify deps (separate
  CLI work), `workflow_lifecycle.go` / `team_lifecycle.go` unused-fn hints.
- Verdict: GO.

### Final Verdict: SHIP READY
- Bug reproduced, root-caused, fixed, regression-tested, full suite green.
- Out of scope (flagged for follow-up): identical schema-vs-struct mismatch on
  `advance_chain.{output,usage}`, `build_team.budget`,
  `complete_task.{result,usage,error}`, `start_workflow.{budget,context}`, and
  `advance_workflow.recovery`. Recommend extracting the new `decodeStartChainContext`
  pattern into a shared helper when the next of these fires in production, or
  migrating those args to `mcp.WithObject` schemas.
- DCO: commit will use `git commit -s`.
